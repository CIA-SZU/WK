function [new,L] = OED_All(x1,y1,dim)
%% orthogonal array (OA) 
u=2;
while (2.^u < dim )
    u = u+1;
end
t=2;
p=t;
V=[];
K=[];
L=[];
D=[];
L1=[];
L2=[];
G=transpose(0:(t-1));
i=1;
while(i<=u)
    R=kron(kron(ones(t^(i-1),1),G),ones(t^(u-i),1));
    V=[V,R];
    i=i+1;
end
V;
U=rref(V');
[m,n]=find(U==1);
[s,t]=find(U((m+1):u,n)<=1);
B=U(:,unique(n(t)))';
L=V*B';
L=mod(L,p);
L=L+ones(size(L,1),size(L,2));
L = L(:,1:dim);
new = zeros(length(L),length(L(1,:)));
for i =1:length(L)
    new(i,find(L(i,:) ==1)) = x1(find(L(i,:) ==1));
    new(i,find(L(i,:) ==2)) = y1(find(L(i,:) ==2));
end
for i =1:length(L(:,1))
    [f(i)]=fnceval(new(i,:));
end

end