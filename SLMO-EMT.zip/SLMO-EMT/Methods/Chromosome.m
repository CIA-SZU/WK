classdef Chromosome
    properties
        rnvec;
        masks;
        objs;
        convio;
        skill_factor;
        front;
        CD;
        rank;
        w;
        is_transfer=0;
        dominationcount=0;
        dominatedset=[];
        dominatedsetlength=0;
        is_child=0;
    end
    
    methods

        function object = DE_mutate(object, x1, x2, x3, F )
            object.rnvec = x1.rnvec + F * (x2.rnvec - x3.rnvec);
            dim  = length(object.rnvec);
            New_rnvec = rand(1,dim);
            index1 = find(object.rnvec>1);
            index2 = find(object.rnvec<0);
            object.rnvec(index1)= New_rnvec(index1);
            object.rnvec(index2)=New_rnvec(index2);
        end
        
        % DE-cross
        function object=DE_cross(object, x, CR)
            replace = rand(1, length(object.rnvec)) > CR;
            replace(randi(length(object.rnvec))) = false;
            object.rnvec(replace) = x.rnvec(replace);
            
            dim  = length(object.rnvec);

            New_rnvec = rand(1,dim);
            index1 = find(object.rnvec>1);
            index2 = find(object.rnvec<0);
            object.rnvec(index1)= New_rnvec(index1);
            object.rnvec(index2)=New_rnvec(index2);

        end

        

%         function [object1,object2] = single_point_crossover(object1,object2,p1,p2,dim)
%             s = randi([1, dim]);
%             object1.masks = [p1.masks(1:s),p2.masks(s+1:end)];
%             object2.masks = [p2.masks(1:s),p1.masks(s+1:end)];
%         end
%         function [object1] = single_point_crossover(object1,p1,p2,dim)
%             s = randi([1, dim]);
%             if(rand(1) < 0.5)
%                 object1.masks = [p1.masks(1:s),p2.masks(s+1:end)];
%             else
%                 object1.masks = [p2.masks(1:s),p1.masks(s+1:end)];
%             end
%         end


%         function object = bitwise_mutation(object,mu,dim)

% %             if rand(1) < mu
% %                 s = randi([1,dim]);
% %                 if object.masks(s) == 0
% %                     object.masks(s) = 1;
% %                 else
% %                     object.masks(s) = 0;
% %                 end
% %             end

% %             mu = 1/dim;
%             for i=1:dim
%                 if rand(1) < mu
%                     if object.masks(i) == 0
%                         object.masks(i) = 1;
%                     else
%                         object.masks(i) = 0;
%                     end
%                 end
%             end
% 
%         end
        

        function population=reset(population,pop)
            for i=1:pop
                population(i).dominationcount=0;
                population(i).dominatedset=[];
                population(i).dominatedsetlength=0;
                population(i).is_child = 0;
                population(i).is_transfer = 0;
            end
        end
    end
    
end

