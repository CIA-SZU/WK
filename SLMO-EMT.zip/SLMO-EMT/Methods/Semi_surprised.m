function index = Semi_surprised(data)
rng('default') 
labeledX = [randn(20,2)*0.25 + ones(20,2);
    randn(20,2)*0.25 - ones(20,2);
    randn(20,2)*0.5];
Y = [ones(20,1); ones(20,1)*2; ones(20,1)*3];
index = 1;
unlabeledX = [randn(100,2)*0.25 + ones(100,2);
              randn(100,2)*0.25 - ones(100,2);
              randn(100,2)*0.5];
trueLabels = [ones(100,1); ones(100,1)*2; ones(100,1)*3];
Mdl = fitsemiself(labeledX,Y,unlabeledX);
maxLabelScores = max(Mdl.LabelScores,[],2);
rescaledScores = rescale(maxLabelScores,0.05,0.95);
scatter(unlabeledX(:,1),unlabeledX(:,2),[],Mdl.FittedLabels,'filled', ...
    'MarkerFaceAlpha','flat','AlphaData',rescaledScores);
title('Fitted Labels for Unlabeled Data')
numWrongLabels = sum(trueLabels ~= Mdl.FittedLabels)
end