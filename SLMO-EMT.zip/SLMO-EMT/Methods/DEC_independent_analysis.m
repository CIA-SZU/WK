function Next_pop = DEC_independent_analysis(pop,tasks)
    masks = [pop.masks];   masks = reshape(masks,tasks.D,[]);  masks = masks';
    objs = [pop.objs];  objs = reshape(objs,tasks.M,[]);  objs = objs';
    Pro_cur = 1 - mean(masks);
    Zero_index = find(Pro_cur == 0);
    [frontnumbers, FrontNO,~] = NDSort(objs,inf);
    Nondominated_pop = find(FrontNO == 1);
    
    
    Next_pop = pop;
end