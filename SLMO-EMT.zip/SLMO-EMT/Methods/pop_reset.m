function population=pop_reset(population,pop)
for i=1:pop
    population(i).dominationcount=0;
    population(i).dominatedset=[];
    population(i).dominatedsetlength=0;
    population(i).is_child = 0;% 子代标记清0
    population(i).is_transfer = 0;% 迁移标记改变为1
end
end