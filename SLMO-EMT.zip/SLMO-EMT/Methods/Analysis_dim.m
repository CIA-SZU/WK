function [rank1,rank2,Dim_ranks] = Analysis_dim(task,k)
% rank1是较大值；rank2是较小值
y = zeros(task.D,task.M);Dim_ranks = zeros(1,task.D);
for i = 1:k
    for j = 1:task.D
        masks = zeros(1,task.D);
        masks(j) = 1;
        if(strfind(task.encoding, 'real'))
            % 直接产生一个10000*10000矩阵，太耗内存了
            Dec = unifrnd(task.lower,task.upper);
        else
            Dec = ones(1,task.D);
        end
%         masks = ones(1,task.D);
%         masks(j) = 0;
        
        % 直接评价
        y(j,:) = Evaluate(masks .* Dec , task);
    end
    cons = zeros(task.D,task.M);
    
%     one_ranks = My_Sort(y);% 同样是越小越好
%     one_ranks = one_ranks';
    [~,one_ranks] = Nondominated_sort(y);% 被支配的个数越小越好

%     one_ranks = NDSort2([y,cons],inf);% 非支配排序,太耗时了
%     load('Dim_ranks.mat');
    Dim_ranks = Dim_ranks + one_ranks;
    
end

figure(1)
scatter(1:task.D,Dim_ranks,10);
% hold on
% plot(mean(Dim_ranks) .* ones(1,task.D));

% 平均值分组
M= mean(Dim_ranks);
rank1 = find(Dim_ranks >= M);
rank2 = find(Dim_ranks < M);
% number = sum(Dim_ranks<mean(Dim_ranks));
[rank1,rank2] = knee_point_Group(Dim_ranks,task);


end

function Dim_ranks = My_Sort(value)% 赋予每个值一个等级值
    [N,D] = size(value);
    % 归一化方法1：max-min方法
    min_v = min(value,[],1);
    max_v = max(value,[],1);
    min_v = repmat(min_v,N,1);
    max_v = repmat(max_v,N,1);
    beta = 1e-4;
    value = (value - min_v ) ./ (max_v - min_v + beta);
    % 归一化方法2：mean方法
%     mean_v = mean(value);
%     value = value - repmat(mean_v,N,1);
    
    Dim_ranks = sum(value,2);
    
end

function [rank1,rank2] = knee_point_Group(Dim_ranks,task)
% 使用knee point
[value,index] = sort(Dim_ranks,'des');
point = [1:task.D;value];
dis = zeros(1,task.D);% 计算最大点，注意这里不是直线距离
for i = 1:task.D
    dis(i) = abs(det([point(:,task.D)-point(:,1),point(:,i)-point(:,1)])) / norm(point(:,task.D)-point(:,1));
end
[~,KN_point] = max(dis);
[value,index] = sort(dis,'descend');
rank1 = index(1 : KN_point);
rank2 = index(KN_point + 1 : task.D);
end