function [Off_dec,Off_masks] = Model_generate(population,tasks)
N = length(population);
D = tasks.D;
Parent_obj = [population.objs];Parent_obj = reshape(Parent_obj,tasks.M,[]);Parent_obj = Parent_obj';
Parent_masks = [population.masks];Parent_masks = reshape(Parent_masks,D,[]);Parent_masks = Parent_masks';
Parent_dec = [population.rnvec];Parent_dec = reshape(Parent_dec,D,[]);Parent_dec = Parent_dec';
costs = Parent_obj;
costs_inv = pinv(costs);
x = Parent_dec .* Parent_masks;
T = costs_inv * Parent_masks;% M*D

figure(1)
scatter(costs(:,1),costs(:,2));
hold on 
for i =1:N
    if rand(1) < 0.5
        costs_new = ( costs(i,:)- rand(1,2).*1 .* costs(i,:) );
    else
        costs_new = ( costs(i,:)+ rand(1,2).*1 .* costs(i,:) );
    end
    Off_dec(i,:) = costs_new * T;
    Off_dec(i,:) = min(max(Off_dec(i,:),tasks.lower),tasks.upper);
    index = find(x(i,:) == 0);
    index_D = randperm(length(index),ceil(length(index)));
    Off_masks(i,:) = ones(1,D);
    Off_masks(i,index(index_D)) = 0;
end
% scatter(new_y1(:,1),new_y1(:,2),'r');

end