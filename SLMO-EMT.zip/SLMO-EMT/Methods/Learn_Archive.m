function Off = Learn_Archive(Sparse_Sets,population)

dim = length(population(1).masks);
N = length(population);
K = length(Sparse_Sets);
Dim_ranks = [Sparse_Sets.masks];
Dim_ranks = reshape(Dim_ranks,dim,[]);
Dim_ranks = Dim_ranks';
Dim_ranks = 1 - mean(Dim_ranks);

Dim_K = dim/2;
for i=1:N
    index_pop = randperm(K,1);
    index_D = randperm(dim,Dim_K);
    Off(i,:) = population(i).masks;
    Off(i,index_D) = Sparse_Sets(index_pop).masks(index_D);
end

end