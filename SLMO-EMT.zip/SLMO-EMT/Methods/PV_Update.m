function PV = PV_Update(population,PV,tasks)
    N = length(population);
    best_pop = population([population.front]==1);
    masks = [best_pop.masks];   masks = reshape(masks,tasks.D,[]);  masks = masks';
    Pro_cur = 1 - mean(masks);
    if(length(PV) == 0)
        PV = Pro_cur;
    else
        PV = PV + (Pro_cur - 0.5)/0.1;
    end
    PV = Pro_cur;
end
    
    