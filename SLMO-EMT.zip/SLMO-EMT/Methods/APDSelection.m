function [Next] = APDSelection(M,objs,RN,theta)
% The environmental selection of RVEA
    [V,~] = UniformPoint(RN,M);
    V(1:RN,:) = V.*repmat(max(objs,[],1)-min(objs,[],1)+eps,size(V,1),1);
    PopObj = objs;
    [N,M]  = size(PopObj);
    NV     = size(V,1);
    PopObj = PopObj - repmat(min(PopObj,[],1),N,1);
    cosine = 1 - pdist2(V,V,'cosine');
    cosine(logical(eye(length(cosine)))) = 0;
    gamma  = min(acos(cosine),[],2);

    %% Associate each solution to a reference vector
    Angle  = acos(1-pdist2(PopObj,V,'cosine'));
    Next   = zeros(1,NV);
    for i  = 1 : NV 
        APD = (1+M*theta*Angle(:,i)/gamma(i)).*sqrt(sum(PopObj.^2,2));
        [~,Next(i)] = min(APD);
        Angle(Next(i),:) = inf;
    end
    % Population for next generation
    
%     Ref    = objs(Next,:);
%     [~,order1] = sort(Ref); 
%     Ref    = Ref(order1(:,1));
end
