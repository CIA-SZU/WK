function Nondominated_Sets = Add_Sets(population,gen,Nondominated_Sets,tasks)
% 说明：
% 刚开始迭代的时候，更多的考虑是稀疏度，所以权重更大，后面则逐步的减少，更考虑目标值，对应的权重增大
% 第一个方法是归一化目标值，那么得保证这两个值在同一个量级中
% 第二个方法是仅仅从非支配解中选择稀疏性高和稀疏性低的
% 还得存储一个决策变量优化的更充分的存档，用来学习dec，但是这个假设是不成立的
% 目前改为masks=1的dec全局优化，这么做其一，是为了防止masks=0的遮蔽影响，
% 其二是因为masks搜索和dec搜索分开了，为了增加dec的搜索频率
% 总的来说，一个存档学习masks，一个存档用来学习dec
% 1.根据自己设定的目标值归一化来判断
% 2.从非支配解中选择，那么更新的话就要通过非支配排序来选择


Nondominated_Sets = Add_nondominated(population,Nondominated_Sets,tasks);
K = ceil(length(population)/5);% 存档为种群个数的1/5

% 这两个集合互不影响
alpha_1 = 0.5;
alpha_2 = 0.6;
% Sparse_Sets = Add_Sparse_Sets(population,gen,Sparse_Sets,tasks,K,alpha_1);
% Dec_Sets = Add_Dec_Sets(population,gen,Dec_Sets,tasks,K,alpha_2);
% Dec_Sets = Add_Dec_Sets_2(gen,Dec_Sets,tasks,K);global FE;FE = FE + K;
% costs1 = [Sparse_Sets.objs];costs1 = reshape(costs1,tasks.M,[]);costs1 = costs1';
% costs2 = [Dec_Sets.objs];costs2 = reshape(costs2,tasks.M,[]);costs2 = costs2';
% scatter(costs1(:,1),costs1(:,2));
% hold on
% scatter(costs2(:,1),costs2(:,2),'red');
end

function Nondominated_Sets = Add_nondominated(population,Nondominated_Sets,tasks)
% 我想要用非支配解和支配解之间来引导进化，但是种群进化中很容易全是非支配解，那么就没有支配解来进行引导
% 于是想着设计一个存档，那么这样即使该种群全是非支配解，那么存档中也有支配解，
% 而且必须改进为体现稀疏大规模问题的特色

% 1.存储每次迭代非支配的个体
% 1.1 怎么改：
% 1.2 存档的时机：
best_pop = population([population.front]==1);
K = 100;
if(isempty(Nondominated_Sets)&&length(best_pop)<=K)% 说明第一次加入
    Nondominated_Sets = best_pop;
else% 说明不是第一次了
    % 去重
    Temp_Sets = [Nondominated_Sets,best_pop];
    costs = [Temp_Sets.objs];costs = reshape(costs,tasks.M,[]);costs = costs';
    [~,uni] = unique(costs,'rows');
    value = sort(uni);
    value = value - length(Nondominated_Sets);
    index=find(value>0);
    value = value(index);
    best_pop_uni = best_pop(value);
    costs1 = [Nondominated_Sets.objs];costs1 = reshape(costs1,tasks.M,[]);costs1 = costs1';
    costs2 = [best_pop_uni.objs];costs2 = reshape(costs2,tasks.M,[]);costs2 = costs2';
%     figure(1)
%     axis([0 4 0 4])
%     scatter(costs1(:,1),costs1(:,2));
%     hold on
%     scatter(costs2(:,1),costs2(:,2),'red');
%     hold off
    if(length(best_pop_uni)<=K-length(Nondominated_Sets))% 说明还有空间加入  
        Nondominated_Sets = [Nondominated_Sets,best_pop_uni];
    else% 说明空间已经满了，关键是如何更新
        % 1.直接替换最先加进来的个体
        % 2.根据非支配排序
        [frontnumbers, FrontNO,~] = NDSort([costs1;costs2],inf);%仅仅根据目标值排序，但是没有说被谁支配
        
        index = find(FrontNO == 1);
        a=1;
    end
end

end


function Sparse_Sets = Add_Sparse_Sets(population,gen,Sparse_Sets,tasks,K,alpha_1)
if(gen~= 1)% 说明已经存储了Sparse_Sets
    % 可能存储重复的，应该去重
    population = [population,Sparse_Sets];
    costs = [population.objs];costs = reshape(costs,tasks.M,[]);costs = costs';
    [~,uni] = unique(costs,'rows');
    population = population(uni);
end

costs = [population.objs];costs = reshape(costs,tasks.M,[]);costs = costs';
masks = [population.masks];masks = reshape(masks,tasks.D,[]);masks = masks';
N = length(population);
Z_min = min(costs,[],1);% idea point
Z_max = max(costs,[],1);
% 考虑目标值有三种方法：
% 1.归一化
% 2.减去最小值，但是范围要考虑
% 3.权重法
costs_z = (costs - repmat(Z_min,N,1)) ./ (repmat(Z_max,N,1) - repmat(Z_min,N,1));
Objs_state = sum(costs_z,2)';% 越小越好
Sparse_state = zeros(1,N);
for i=1:N   
    Sparse_state(i) = sum(masks(i,:))/tasks.D;% 表示1的个数   
end
% alpha_1 = 0.5;
All_state = alpha_1 .* Sparse_state + (1-alpha_1) .* Objs_state;
[~,index] = sort(All_state);
Sparse_Sets = population(index(1:K));
end

function Dec_Sets = Add_Dec_Sets(population,gen,Dec_Sets,tasks,K,alpha_2)
if(gen~= 1)% 说明已经存储了Dec_Sets
    % 可能存储重复的，应该去重
    population = [population,Dec_Sets];
    costs = [population.objs];costs = reshape(costs,tasks.M,[]);costs = costs';
    [~,uni] = unique(costs,'rows');
    population = population(uni);
end
costs = [population.objs];costs = reshape(costs,tasks.M,[]);costs = costs';
masks = [population.masks];masks = reshape(masks,tasks.D,[]);masks = masks';
N = length(population);
Z_min = min(costs,[],1);% idea point
Z_max = max(costs,[],1);
% 考虑目标值有三种方法：
% 1.归一化
% 2.减去最小值，但是范围要考虑
% 3.权重法
costs_z = (costs - repmat(Z_min,N,1)) ./ (repmat(Z_max,N,1) - repmat(Z_min,N,1));
Objs_state = sum(costs_z,2)';% 越小越好
Sparse_state = zeros(1,N);
for i=1:N   
    Sparse_state(i) = sum(masks(i,:))/tasks.D;% 表示1的个数
end
All_state = alpha_2 .* (1 - Sparse_state) + (1-alpha_2) .* Objs_state;% 稀疏度越低越好
[~,index] = sort(All_state);
Dec_Sets = population(index(1:K));
end

function Dec_Sets = Add_Dec_Sets_2(gen,Dec_Sets,tasks,K)
% 这里之所以设计masks=0的dec独立进化，是因为我以为这样对于dec的搜索更准
% 其实不然，后面我分析这是不对的
    if(gen ==1 )
        Dec = unifrnd(repmat(tasks.lower,K,1),repmat(tasks.upper,K,1));
        Masks = ones(K,tasks.D);
        clear Dec_Sets
        for i=1:K
            Dec_Sets(i) = Chromosome;
            Dec_Sets(i).rnvec = Dec(i,:);
            Dec_Sets(i).masks = Masks(i,:);
            Dec_Sets(i).objs = Evaluate(Dec_Sets(i).rnvec .* Dec_Sets(i).masks ,tasks);
        end
        Dec_Sets = My_environmentselect(Dec_Sets,K,tasks);
    else
        tour_oder = TournamentSelection2(2,2*K,[Dec_Sets.front],-[Dec_Sets.CD]);
        Parent = Dec_Sets(tour_oder);
        Parent_dec = [Parent.rnvec];Parent_dec = reshape(Parent_dec,tasks.D,[]);Parent_dec = Parent_dec';
        Parent1_dec = Parent_dec(1:K,:);Parent2_dec = Parent_dec(K+1:end,:);
        global param
        Offspring = GA_SBX(Parent1_dec,Parent2_dec,param);
        Offspring = GA_PM(Offspring,param,tasks);
        for i=1:K
            Child(i) = Chromosome;
            Child(i).rnvec = Offspring(i,:);
            Child(i).masks = ones(1,tasks.D);
            Child(i).objs = Evaluate(Child(i).rnvec .* Child(i).masks ,tasks);
        end
        Dec_Sets = My_environmentselect([Dec_Sets,Child],K,tasks);
    end
    
end

function Dec_Sets = Add_Dec_Sets_3(Dec_Sets,tasks)
% 这一套东西构思步骤要慢，慢工出细活，出精品
% 一：想法：
% 因为dec搜索太慢了，虽然masks完全判断准，再进行普通dec搜索也可以
% 但是masks完全判断准又几乎不可能，因为它需要dec进化充分的帮助
% 这是验证过的，而这就是现象
% 二：分析现象：
% 1.为什么masks准dec搜索的就充分,masks不准dec搜索的就不充分
% 1.1 从难度来讲，由于masks将后面的masks的置为0，dec不影响后面维度的取值，
% 那么搜索难度从10000将为1000维度。这也是从masks完全搜索准确和masks完全不搜索的角度，
% 也是从masks辅助dec搜索和dec直接搜索的角度 
% 1.2 如果masks完全不准确，也就是完全相反，那么dec也就是要搜索后面的9000维度为0，难度就变大了九倍
% 而且前面的维度也由于改变不了，导致陷入局部解。这个时候就要考虑误判的情况，让算法能够自动及时修正masks

% 2.为什么用x搜索代替dec搜索，搜索的准确率反而还下降了
% 2.1 对于真正为0的不影响，但是是对于误判为0的，那么这个维度就更多是0固定值的
% 而产生的个体更多的在0附近，这么一来就偏离最优解了


% 三：问题：
% 1.对于D*theta>100的问题来说，那也是一个大规模问题，SBX算子来解决也不行
% 并且验证过即使masks完全判断准了，SBX搜索的准确度也是40%左右，很低
% 2.由于两个编码的存在，并且相互之间没有构建联系，导致dec的搜索跟不充分
% 所以这里尝试使用一种方向向量的引导搜索,增加dec的搜索充分度
% 3.对于大规模来说，SBX搜索非常耗时，这方面至少有两篇论文提到了，随着维度的增加，SBX导致
% 的资源消耗也增大
% 4,提出一个概念，就是稀疏大规模的早熟和局部最优往往表现在过于稀疏化，其中一个方面就是
% 多目标函数中的其中一个目标函数是考虑决策变量的稀疏度，但是这样做往往导致误导影响另一个/多个目标函数
% 的优化，导致局部最优

% 四：其它算法考虑不周到的地方（要分A.大规模算法和B.大规模稀疏算法）：
% 1.B的算法大多评价次数过高

% 五：为什么能保证这个方法就能解决？
% 1.SBX的搜索产生的子代质量并不高，导致dec搜索不充分。比如不能很好的平衡探索和利用，
% only provide limited exploitation performance in some local
% regions；其中beta控制子代和父代的差异和距离，如果为1则完全相同，一般是1附近
% 2.其次在父代池选择的策略也不合理，比如非支配解利用率也不高
% 3.仅仅使用dec进行搜索，而masks的存在会导致dec的遮蔽影响搜索不充分


end

function Offspring = GA_SBX(Parent1,Parent2,param)
proC = param.proC;
disC = param.disC;
proM = param.proM;
disM = param.disM;
%% Simulated binary crossover
[N,D] = size(Parent1);
beta  = zeros(N,D);
mu    = rand(N,D);
beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));

beta = beta.*(-1).^randi([0,1],N,D);
beta(rand(N,D)<0.5) = 1;
beta(repmat(rand(N,1)>proC,1,D)) = 1;
Offspring = (Parent1+Parent2)/2+beta.*(Parent1-Parent2)/2;
   
end
function Offspring = GA_PM(Offspring,param,task)
proC = param.proC;
disC = param.disC;
proM = param.proM;
disM = param.disM;
[N,D] = size(Offspring);
%% Polynomial mutation
Lower = repmat(task.lower,N,1);% 这里相当于用解码值
Upper = repmat(task.upper,N,1);
Site  = rand(N,D) < proM/D;
mu    = rand(N,D);
temp  = Site & mu<=0.5;
% 这里作为边界处理
lower_index = Offspring < Lower;
upper_index = Offspring > Upper;
all_index = lower_index | upper_index;
New_pop = rand(N,D);
Offspring(all_index) = New_pop(all_index);% 作为替换
% Offspring       = min(max(Offspring,Lower),Upper);
Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
    (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
temp = Site & mu>0.5;
Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
    (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));

end
