function [data_MOMFEA,Record_score,PV]=Multipop(pop,tasks,maxFE,reps,benchMark_num)
no_of_tasks = length(tasks);

subpop = pop/no_of_tasks;
dim = length(tasks(1).upper);
for k = 2:no_of_tasks
    temp_dim = length(tasks(k).upper);
    if(temp_dim > dim) 
        dim = temp_dim;
    end
end
warning off;

%% 初始化参数
Record_score = [];
FE = 0;% 评价次数
gen = 1;% 迭代次数
[param.proC,param.disC,param.proM,param.disM] = deal(1,20,1,20); % SBX交叉变异参数
Record_sparse = [];
Record_allO_Z = [];
entropy = [];
Nondominated_Sets = [];
%%
for rep = 1:reps
     % 初始化种群
    PV = 0.5.*ones(1,dim);% 概率向量
    [population,~] = initialize(pop,tasks,PV);
    
    % 增加评价次数
    FE = FE + pop;
    % 排序
    population = My_environmentselect(population,subpop,tasks);
    k_optimum = getoptims(tasks);

    % 输出
    score = Cal_disp(population,benchMark_num,tasks,k_optimum,gen);
    

    gen =2;
    while FE < maxFE
        tasks.FE_pro = FE / maxFE;

        best_pop = population([population.front]==1);
        dec = [best_pop.rnvec]; dec = reshape(dec,dim,[]);  dec = dec';

        Mean_dec = mean(dec);
        temp_dec = dec(:,2:tasks.D/10+1);
        flag = 0;
        for i=1:length(temp_dec(:))
            if(temp_dec(i)>0.8&&temp_dec(i)<1.3)
                flag = flag + 1;
            end
        end

        Pop1 = pop * 0.8; 
        Pop2 = pop * 0.1;
        Pop3 = pop * 0.1;
        All_Pop = randperm(pop);
        Population_1 = population(All_Pop(1:Pop1));     Child_1 = Child_initial(Pop1);
        Population_2 = population(All_Pop(1 + Pop1 : Pop1 + Pop2));     Child_2 = Child_initial(Pop2);
        Population_3 = population(All_Pop(Pop1 + Pop2+1 : end));        Child_3 = Child_initial(Pop3);

        tour_oder = TournamentSelection2(2,2*Pop1,[Population_1.front],-[Population_1.CD]);

        [Offspring_masks,~,~] = Operator_masks(Population_1,tour_oder,param,PV,tasks);
        for i =1 : Pop1
            Child_1(i).masks = Offspring_masks(i,:);
            Child_1(i).is_child = 1;
        end
        [Offspring_dec,~] = Operator_dec(Population_1,tour_oder,tasks,param,PV);
        for i =1 : Pop1
            Child_1(i).rnvec = Offspring_dec(i,:);
            Child_1(i).is_child = 1;
        end
        
        for j=1:Pop1
            if strcmp(tasks.name,'Sparse_NN') == 1
                Child_1(j).rnvec = Sparse_NN.CalDec(tasks,Child_1(j).rnvec);
                Child_1(j).masks = ones(1,dim);
            end
            Child_1(j).objs = Evaluate(Child_1(j).rnvec .* Child_1(j).masks,tasks);
            FE = FE + 1;
        end
        

        Population_1=reset(Population_1,Pop1);

        intpopulation(1:Pop1)=Population_1;
        intpopulation(Pop1+1:2*Pop1)=Child_1;
        Population_1 = My_environmentselect(intpopulation,Pop1,tasks);


        Population_2 = DEC_independent_analysis(Population_2,tasks);
        


        

        Survive_pop = population;

        score = Cal_disp(Survive_pop,benchMark_num,tasks,k_optimum,gen);

        R_index = length(Record_score);
        Record_score(R_index+1) = score;
        
        
        gen = gen + 1;
    end
end
%% 画维度值图
% figure(1)
% x = 1:1:dim/10;
% plot(x,population(1).masks(1:dim/10) .* population(1).rnvec(1:dim/10));
% % plot(x,population(1).rnvec(1:dim/10));
% axis([1 dim/10 min(tasks.lower) max(tasks.upper)])
%
% figure(2)
% x = dim/10+1:1:dim;
% plot(x,population(1).masks(dim/10+1:dim).*population(1).rnvec(dim/10+1:dim));
% % plot(x,population(1).rnvec(dim/10+1:dim));
% axis([dim/10+1 dim min(tasks.lower) max(tasks.upper)])

%% 画score图
% figure(1)
% x = 1:1:R_index+1;
% plot(x,Record_score);
%%
data_MOMFEA = population;
end

function child = Child_initial(pop)
    for i =1:pop
        child(i) = Chromosome;
    end
end

% 更新Update