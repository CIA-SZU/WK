function [data_MOMFEA,Record_score,Dim_ranks]=MultiTasks(subpop,tasks,maxFE,reps,benchMark_num)
warning off;

no_of_tasks = 2;
IGD =inf(1,no_of_tasks);
HV =zeros(1,no_of_tasks);
pop = subpop * no_of_tasks;
dim = length(tasks(1).upper);
% for k = 2:no_of_tasks
%     temp_dim = length(tasks(k).upper);
%     if(temp_dim > dim) 
%         dim = temp_dim;
%     end
% end
Record_score = [];
gen = 1;
rmp = 0.5;

[param.proC,param.disC,param.proM,param.disM] = deal(1,20,1,20); 
Record_sparse = [];
Record_allO_Z = [];
entropy = [];
Nondominated_Sets = [];
%%
for rep = 1:reps
     % 初始化种群
     Dim_ranks = 0.5.*ones(1,dim);
    [population,~] = initialize(pop,tasks,Dim_ranks);
    for i =1 : pop
%         Child(i) = Chromosome;
        population(i).skill_factor = ceil(i/subpop);
    end
    

    FE = FE + pop;

    k_optimum = getoptims(tasks);

    for i = 1:no_of_tasks
        population((i-1)*subpop+1 : i*subpop ) = My_environmentselect(population((i-1)*subpop+1 : i*subpop ),subpop,tasks);
        score(i) = Cal_disp(population((i-1)*subpop+1 : i*subpop ),benchMark_num,tasks,k_optimum,gen);
    end
    

    gen =2;
    while FE < maxFE
        for i = 1:no_of_tasks

            sub_population = population((i-1)*subpop+1 : i*subpop);
            %
            tour_oder = TournamentSelection2(2,2*subpop,[sub_population.front],-[sub_population.CD]);%锦标赛父代池,dec和masks统一用这个顺序
            Parent1 = sub_population(tour_oder(1:subpop));
            Parent2 = sub_population(tour_oder(1+subpop : 2*subpop));
            
%             for j = (i-1) * subpop + 1 : 2*subpop
            for j = 1:subpop
                Child(j) = Chromosome;
                Offspring = MultiMasksSearch(Parent1(j),Parent2(j));
                Child(j).masks = Offspring;
                Offspring = MultiDecSearch(Parent1(j), Parent2(j), param, tasks);
                Child(j).rnvec = Offspring;
                Child(j).skill_factor = i;
                Child(j).objs = Evaluate(Child(j).rnvec .* Child(j).masks ,tasks);
            end
            
            FE = FE + subpop;

            sub_population=reset(sub_population ,subpop);
            Newpopulation((i-1)*subpop*2+1 : i*subpop*2) = [sub_population,Child];
        end
        
        % 准备下一代的个体
        population = [];
        
        for i = 1:no_of_tasks
            sub_population = Newpopulation([Newpopulation.skill_factor]== i);
            sub_population = My_environmentselect(sub_population,subpop,tasks);
            % 评价输出
            score = Cal_disp(sub_population,benchMark_num,tasks,k_optimum,gen);
                    population = [population,sub_population];
        end
        
        gen = gen + 1;
        
    end
end
data_MOMFEA = population;
end