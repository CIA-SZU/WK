function Offspring = MultiMasksSearch(Parent1,Parent2)
Parent1 = Parent1.masks;
Parent2 = Parent2.masks;
% Offspring = GA_UC(Parent1,Parent2);
Offspring = GA_SC(Parent1,Parent2);
Offspring = GA_BFM(Offspring,1);

end


function Offspring = GA_SC(Parent1,Parent2)
proC = 1;
[N,D] = size(Parent1);

k = repmat(1:D,N,1) > repmat(randi(D,N,1),1,D);
k(repmat(rand(N,1)>proC,1,D)) = false;
Offspring    = Parent1;
Offspring(k) = Parent2(k);

end

function Offspring = GA_UC(Parent1,Parent2)
proC = 1;

[N,D] = size(Parent1);
k     = rand(N,D) < 0.5;
k(repmat(rand(N,1)>proC,1,D)) = false;
Offspring    = Parent1;
Offspring(k) = Parent2(k);
end


function Offspring = GA_BFM(Offspring,proM)
[N,D] = size(Offspring);

Site = rand(N,D) < proM/D;
Offspring(Site) = ~Offspring(Site);
end