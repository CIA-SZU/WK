function Offspring = MultiDecSearch(Parent1, Parent2, param, tasks)
    Parent1 = Parent1.rnvec;
    Parent2 = Parent2.rnvec;
    Offspring = GA_SBX(Parent1,Parent2,param);
    Offspring = Boundary_treat(Offspring,tasks);
    Offspring = GA_PM(Offspring,param,tasks);
    
end

function Offspring = GA_SBX(Parent1,Parent2,param)
proC = param.proC;
disC = param.disC;
proM = param.proM;
disM = param.disM;
%% Simulated binary crossover
[N,D] = size(Parent1);
beta  = zeros(N,D);
mu    = rand(N,D);
beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));

beta = beta.*(-1).^randi([0,1],N,D);
beta(rand(N,D)<0.5) = 1;
beta(repmat(rand(N,1)>proC,1,D)) = 1;
Offspring = (Parent1+Parent2)/2+beta.*(Parent1-Parent2)/2;
   
end


function Offspring = Boundary_treat(Offspring,tasks)
[N,D] = size(Offspring);

Lower = repmat(tasks.lower,N,1);
Upper = repmat(tasks.upper,N,1);
lower_index = Offspring < Lower;
upper_index = Offspring > Upper;
all_index = lower_index | upper_index;
New_pop = rand(N,D);

Offspring(all_index) = New_pop(all_index);


end

function Offspring = GA_PM(Offspring,param,task)
proC = param.proC;
disC = param.disC;
proM = param.proM;
disM = param.disM;
[N,D] = size(Offspring);

Lower = repmat(task.lower,N,1);
Upper = repmat(task.upper,N,1);
Site  = rand(N,D) < proM/D;
mu    = rand(N,D);
temp  = Site & mu<=0.5;



Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
    (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
temp = Site & mu>0.5;
Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
    (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
end
