
function index = IndexShow(population,tasks)

Parent_masks = [population.masks];Parent_masks = reshape(Parent_masks,tasks.D,[]);Parent_masks = Parent_masks';
Mean_pop = mean(Parent_masks);
zero_num11 = mean(Mean_pop(1:tasks.D/10+1));
zero_num22 = mean(Mean_pop(tasks.D/10+2:end));
index(1) = zero_num11;
index(2) = zero_num22;

end