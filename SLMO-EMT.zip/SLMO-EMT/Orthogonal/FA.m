function new_temp = FA(L,f,x1,y1)
%% factor analysis因子分析
S = zeros(length(L(1,:)),2);
for i =1:length(L(1,:))
    S(i,1) = sum(f(find(L(:,i) == 1)))/length(find(L(:,i) == 1));
    S(i,2) = sum(f(find(L(:,i) == 2)))/length(find(L(:,i) == 2));
end
[~,number] = min(S,[],2);
for i = 1:length(number)
    if(number(i) == 1)
        new_temp(i) = x1(i);
    else
        new_temp(i) = y1(i);
    end
end