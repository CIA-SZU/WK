clear
% t0 = tic;
% pause(1)
t1 = tic;
% pause(1)
toc(t1);