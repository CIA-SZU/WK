function population = My_environmentselect(intpopulation_T,subpop,tasks)
T_pop=length(intpopulation_T);
pop_objs_T=[];
no_of_objs = length(intpopulation_T(1).objs);
for i=1:T_pop
    pop_objs_T(i,:) = intpopulation_T(i).objs;
end
[frontnumbers, FrontNO,~] = NDSort(pop_objs_T,inf);
for i=1:T_pop
    intpopulation_T(i).front = FrontNO(i);
end
[intpopulation_T,~]=SolutionComparison.diversity(intpopulation_T,frontnumbers,T_pop,no_of_objs);
population = intpopulation_T(1:subpop);
end
function index = Explore_select(intpopulation_T,ratio)
    N = length(intpopulation_T);
    D = length(intpopulation_T(1).masks);
    Sparse_pro = zeros(1,N);
    for i = 1:N
        Sparse_pro(i) = 1 - sum(intpopulation_T(i).masks) / D ;
    end
    index = TournamentSelection2(2,ratio,Sparse_pro);
end