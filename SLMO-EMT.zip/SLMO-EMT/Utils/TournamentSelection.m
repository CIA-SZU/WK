function Sel = TournamentSelection(K,Fit)
Sel = [];
for i = 1:length(Fit)
    temp = randi(length(Fit),1,K);
    [~,index] = min(Fit(temp));
    Sel(i) = temp(index);
    
end

end