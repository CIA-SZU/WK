function [frontnumbers , FrontNO,MaxFNO] = NDSort(PopObj,nSort)
    [N,M] = size(PopObj);
    FrontNO = inf(1,N);
    MaxFNO  = 0;
    [PopObj,rank] = sortrows(PopObj);
    while sum(FrontNO<inf) < min(nSort,N)
        MaxFNO = MaxFNO + 1;
        for i = 1 : N
            if FrontNO(i) == inf
                Dominated = false;
                for j = i-1 : -1 : 1
                    if FrontNO(j) == MaxFNO
                        m = 2;
                        while m <= M && PopObj(i,m) >= PopObj(j,m)
                            m = m + 1;
                        end
                        Dominated = m > M;
                        if Dominated || M == 2
                            break;
                        end
                    end
                end
                if ~Dominated
                    FrontNO(i) = MaxFNO;
                end
            end
        end
    end
    FrontNO(rank) = FrontNO;
    for i=1:MaxFNO
    frontnumbers(i) = length(find(FrontNO==i));
    end
end