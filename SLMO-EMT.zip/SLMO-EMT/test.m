Data = rand(2600,500);
n = randi(2,2600,1) - 1;
Data = [Data n];
save("Madelon","Data");
