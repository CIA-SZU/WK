%%
% Author：Kan Wang
% Email：wk1019591719@163.com
%%
function [data_MOMFEA,Record_score,Dim_ranks]=SLMO_EMT(subpop,tasks,maxFE,reps,benchMark_num,d_1,d_2,alpha,lambda,theta,p_1)
    warning off;
    no_of_tasks = 3;
    IGD =inf(1,no_of_tasks);
    HV =zeros(1,no_of_tasks);
    pop = subpop * no_of_tasks;
    dim = length(tasks(1).upper);
Record_score = [];
Record_index = 1;
FE = 0;
gen = 1;
[param.proC,param.disC,param.proM,param.disM] = deal(1,20,1,20); 
Record_sparse = [];
        Record_allO_Z = [];
        entropy = [];
        Nondominated_Sets = [];
        PV = 0.5 * ones(1,dim);
        k_optimum = getoptims(tasks);
        rmp_1 = 0.5;
        rmp_2 = 0.5;
        Windows_1 = 0;
        Windows_2 = 0;
        Dim_ranks_2 = 0.5 * ones(1,tasks.D);
        score = 0;
        for rep = 1:reps
            Dim_ranks = 0.5.*ones(1,dim);
            [population,~] = initialize(subpop,tasks,Dim_ranks);
            for i= 1:subpop
         population(i).skill_factor = 1;
     end
     FE = FE + subpop;
     population(1 : subpop) = My_environmentselect(population(1 : subpop),subpop,tasks);
     score = Cal_disp(population(1 : subpop ),benchMark_num,tasks,k_optimum,gen);
     Pareto_pop = population([population.front] == 1);
            Masks_1 = [Pareto_pop.masks]; Masks_1 = reshape(Masks_1,tasks.D,[]); Masks_1 = Masks_1';
            Dec_1 = [Pareto_pop.rnvec]; Dec_1 = reshape(Dec_1,tasks.D,[]); Dec_1 = Dec_1';
            M_Masks_1 = 1 - mean(Masks_1);
            Dec_Bind = Pareto_pop(randperm(length(Pareto_pop),1)).rnvec;
            M_M_ranks_1 = abs(M_Masks_1 - 0.5);
            [values, index] = sort(M_M_ranks_1);
            index_range_1 = find(M_M_ranks_1 <= alpha);
            if (length(index_range_1)/tasks.D) >= d_1
                Subtask_2_range = index_range_1;
            else
                Subtask_2_range = index(1:tasks.D * d_1);
            end
     for i = 1:subpop
         Masks(i,:) = rand(1,dim) > M_Masks_1;
     end
     St_2_Sparse_D = M_Masks_1(Subtask_2_range);
     nowIndex = 1;
     for i= 1+subpop : 2*subpop
         R = rand(1,tasks.D);
         population(i).masks = Masks(nowIndex,:);
         population(i).rnvec = Dec_Bind;
         population(i).skill_factor = 2;
         population(i).objs = Evaluate(Dec_Bind .* population(i).masks ,tasks);
         nowIndex = nowIndex + 1;
     end
     FE = FE + subpop;
                Task2_Upper = Pareto_pop(1).rnvec;
                for i = 1:length(Pareto_pop)
                    Task2_Upper = max([Task2_Upper;Pareto_pop(i).rnvec]);
                end
                Task2_Lower = Pareto_pop(1).rnvec;
                for i = 1:length(Pareto_pop)
                    Task2_Lower = min([Task2_Lower;Pareto_pop(i).rnvec]);
                end
                Masks_Bind = Pareto_pop(randperm(length(Pareto_pop),1)).masks;
                [~,index] = sort(M_Masks_1);
                per_index = index(1: d_2 * tasks.D);
                index_2 = randperm(floor(d_2 * tasks.D), floor(d_2 * d_2 * tasks.D));
    Additional_range = per_index(index_2);
    Masks_Bind(Additional_range) = 1;
    Subtask_3_range = find(Masks_Bind == 1);
    Dec = DecInitialize(subpop, Task2_Lower, Task2_Upper);
     j = 1;
     for i= 1+2 * subpop : 3*subpop
                    population(i).rnvec = Dec(j,:);
                    population(i).masks = Masks_Bind;
                    j = j + 1;
                    population(i).skill_factor = 3;
                    population(i).objs = Evaluate(Masks_Bind .* population(i).rnvec ,tasks);
                end
                FE = FE + subpop;
                
                for i = 2:no_of_tasks
                    population((i-1)*subpop+1 : i*subpop ) = My_environmentselect(population((i-1)*subpop+1 : i*subpop ),subpop,tasks);
        score = Cal_disp(population((i-1)*subpop+1 : i*subpop ),benchMark_num,tasks,k_optimum,gen);
    end
    gen =2;
    while FE < maxFE
        flag = (rand()<0.5) + 1;
        sub_population_1 = population(1:subpop);
            Pareto_pop = population([population.front] == 1);
            Masks_1 = [Pareto_pop.masks]; Masks_1 = reshape(Masks_1,tasks.D,[]); Masks_1 = Masks_1';
            Dec_1 = [Pareto_pop.rnvec]; Dec_1 = reshape(Dec_1,tasks.D,[]); Dec_1 = Dec_1';
            M_Masks_1 = 1 - mean(Masks_1);
        if(Windows_1 == lambda)
            Dec_Bind = Pareto_pop(randperm(length(Pareto_pop),1)).rnvec;
                        M_M_ranks_1 = abs(M_Masks_1 - 0.5);[values, index] = sort(M_M_ranks_1);
                        index_range_1 = find(M_M_ranks_1 <= alpha);
                        if (length(index_range_1)/tasks.D) >= d_1
         Subtask_2_range = index_range_1;
     else
         Subtask_2_range = index(1:tasks.D * d_1);
     end
     for i = 1:subpop
         Masks(i,:) = rand(1,dim) > M_Masks_1;
     end
     St_2_Sparse_D = M_Masks_1(Subtask_2_range);
     nowIndex = 1;
        for i= 1+subpop : 2*subpop
            R = rand(1,tasks.D);
            population(i).masks = Masks(nowIndex,:);
            population(i).rnvec = Dec_Bind;
         population(i).skill_factor = 2;
         population(i).objs = Evaluate(Dec_Bind .* population(i).masks ,tasks);
         nowIndex = nowIndex + 1;
     end
            Windows_1 = 0;
            rmp_1 = 0.5;
            
            FE = FE + subpop;
        end
        if(Windows_2 == lambda)
                    Task2_Upper = Pareto_pop(1).rnvec;
                    for i = 1:length(Pareto_pop)
                        Task2_Upper = max([Task2_Upper;Pareto_pop(i).rnvec]);
                    end
                    Task2_Lower = Pareto_pop(1).rnvec;
                    for i = 1:length(Pareto_pop)
                        Task2_Lower = min([Task2_Lower;Pareto_pop(i).rnvec]);
                    end
                    Masks_Bind = Pareto_pop(randperm(length(Pareto_pop),1)).masks;
                    [~,index] = sort(M_Masks_1);
            per_index = index(1: d_2 * tasks.D); 
            index_2 = randperm(floor(d_2 * tasks.D), floor(d_2 * d_2 * tasks.D));
            Additional_range = per_index(index_2);
            Masks_Bind(Additional_range) = 1;
            Subtask_3_range = find(Masks_Bind == 1);
            Dec = DecInitialize(subpop, Task2_Lower, Task2_Upper);
             j = 1;
             for i= 1+2 * subpop : 3*subpop
                 population(i).rnvec = Dec(j,:);
                 population(i).masks = Masks_Bind;
                 j = j + 1;
                 population(i).skill_factor = 3;
                 population(i).objs = Evaluate(Masks_Bind .* population(i).rnvec ,tasks);
             end
            Windows_2 = 0;
            rmp_2 = 0.5;
            FE = FE + subpop;
        end
                    population(1+subpop : subpop*2) = DecSearch_3_All(population(1+subpop : subpop*2), tasks, Subtask_3_range);
                    FE = FE + subpop;
population(1+2*subpop : subpop*3) = MasksSearch_2_All(population(1+2*subpop : subpop*3), tasks, Subtask_2_range);
                    FE = FE + subpop;
sub_population_1 = population(1 : subpop);
                        for mm = 1:subpop
                            FrontNo_1(mm) = sub_population_1(mm).front;
                            CrowdDis_1(mm) = sub_population_1(mm).CD;
                        end
                        MatingPool_1 = TournamentSelection2(2,2*subpop,FrontNo_1,-CrowdDis_1);
sub_population_1_T = sub_population_1(MatingPool_1);
                        sub_population_2 = population(subpop+1 : 2*subpop);
                        for mm = 1:subpop
                            FrontNo_2(mm) = sub_population_2(mm).front;
                            CrowdDis_2(mm) = sub_population_2(mm).CD;
                        end
                        MatingPool_2 = TournamentSelection2(2,2*subpop,FrontNo_2,-CrowdDis_2);
sub_population_2_T = sub_population_2(MatingPool_2);
                        sub_population_3 = population(2*subpop+1 : 3*subpop);
                        for mm = 1:subpop
                            FrontNo_3(mm) = sub_population_3(mm).front;
                            CrowdDis_3(mm) = sub_population_3(mm).CD;
                        end
                        MatingPool_3 = TournamentSelection2(2,2*subpop,FrontNo_3,-CrowdDis_3);
                        sub_population_3_T = sub_population_3(MatingPool_2);
                        Dec_1 = [sub_population_1_T.rnvec]; Dec_1 = reshape(Dec_1,tasks.D,[]); Dec_1 = Dec_1';
                        Dec_2 = sub_population_2_T(1).rnvec;
                Diff_1_2 = 1 - pdist2(Dec_2,Dec_1) / pdist2(tasks.lower,tasks.upper);

Masks_1 = [sub_population_1_T.masks]; Masks_1 = reshape(Masks_1,tasks.D,[]); Masks_1 = Masks_1';
Masks_2 = sub_population_3_T(1).masks;
Diff_1_3 = sum((Masks_1 == Masks_2),2)';
                Sum_1_2 = 0;
                Sum_1_3 = 0;
                for j = 1: subpop
                    if(flag == 1)
    if(rand() < rmp_1)
                            Sum_1_2 = Sum_1_2 + 1;
                                p_index = TournamentSelection2(2,1,-Diff_1_2);
                                q_index = randi(length(sub_population_2_T));
                                Child(j) = Search_1_2(sub_population_1_T(p_index), sub_population_2_T(q_index), Subtask_2_range, tasks);
                                sub_population_1_T(p_index) = [];
                                sub_population_2_T(q_index) = [];
                            Diff_1_2(p_index) = [];
                            Diff_1_3(p_index) = [];
                            flag = 2;
    elseif(rand() < rmp_2)
                                Sum_1_3 = Sum_1_3 + 1;
                                p_index = TournamentSelection2(2,1,-Diff_1_3);
                                q_index = randi(length(sub_population_3_T));
                                Child(j) = Search_1_3(sub_population_1_T(p_index), sub_population_3_T(q_index), Subtask_3_range, tasks);
                                sub_population_1_T(p_index) = [];
                                sub_population_3_T(q_index) = [];
                                Diff_1_3(p_index) = [];
                            Diff_1_2(p_index) = [];
                            flag = 1;
    else
        p_index = randi(length(sub_population_1_T));
                            q_index = randi(length(sub_population_1_T));
                            while(p_index == q_index)
                                q_index = randi(length(sub_population_1_T));
    end
                                Parent1 = sub_population_1_T(p_index);
                                    Parent2 = sub_population_1_T(q_index);
                                    Child(j) = Search_1_All(Parent1, Parent2, tasks);
                                    if(p_index > q_index)
                                    sub_population_1_T(p_index) = [];
                                    sub_population_1_T(q_index) = [];
                                    Diff_1_2(p_index) = [];
                                    Diff_1_2(q_index) = [];
                                    Diff_1_3(p_index) = [];
                                Diff_1_3(q_index) = [];
    else
                                sub_population_1_T(q_index) = [];
                                sub_population_1_T(p_index) = [];
                                Diff_1_2(q_index) = [];
                                Diff_1_2(p_index) = [];
                                Diff_1_3(q_index) = [];
                                Diff_1_3(p_index) = [];
      end
           end
                    else
                        if(rand() < rmp_2)
Sum_1_3 = Sum_1_3 + 1;
         p_index = TournamentSelection2(2,1,-Diff_1_3);
     q_index = randi(length(sub_population_3_T));
     Child(j) = Search_1_3(sub_population_1_T(p_index), sub_population_3_T(q_index), Subtask_3_range, tasks);
     sub_population_1_T(p_index) = [];
                            sub_population_3_T(q_index) = [];
                            Diff_1_2(p_index) = [];
                            Diff_1_3(p_index) = [];
      flag = 1;
elseif(rand() < rmp_1)
                                    Sum_1_2 = Sum_1_2 + 1;
                                    p_index = TournamentSelection2(2,1,Diff_1_2);
                                    q_index = randi(length(sub_population_2_T));
                                    Child(j) = Search_1_2(sub_population_1_T(p_index), sub_population_2_T(q_index), Subtask_2_range, tasks);
                                    sub_population_1_T(p_index) = [];
                                    sub_population_2_T(q_index) = [];
                                    Diff_1_2(p_index) = [];
                            Diff_1_3(p_index) = [];
                            flag = 2;
else
                                p_index = randi(length(sub_population_1_T));
                                q_index = randi(length(sub_population_1_T));
                                while(p_index == q_index)
                                    q_index = randi(length(sub_population_1_T));
                                end
Parent1 = sub_population_1_T(p_index);
Parent2 = sub_population_1_T(q_index);
                            Child(j) = Search_1_All(Parent1, Parent2, tasks);
if(p_index > q_index)
                        sub_population_1_T(p_index) = [];
                        sub_population_1_T(q_index) = [];
                        Diff_1_2(p_index) = [];
                        Diff_1_2(q_index) = [];
                        Diff_1_3(p_index) = [];
                        Diff_1_3(q_index) = [];
else
                      sub_population_1_T(q_index) = [];
                      sub_population_1_T(p_index) = [];
                    Diff_1_2(q_index) = [];
                                Diff_1_2(p_index) = [];
                                Diff_1_3(q_index) = [];
                                Diff_1_3(p_index) = [];
end
                        end
                    end
                end
                FE = FE + subpop;
                        Newpopulation(1 : subpop*2) = [population(1:subpop),Child];
                        sub_population = My_environmentselect(Newpopulation,subpop,tasks);
                        population(1 : subpop) = sub_population;
                        Success_2 = 0;
                        Success_3 = 0;
                        for kk = 1:subpop
                            if(sub_population(kk).is_transfer == 2)
                                Success_2 = Success_2 + 1;
                            end
                            if(sub_population(kk).is_transfer == 3)
                                Success_3 = Success_3 + 1;
                end
            end
if(Sum_1_2 == 0)
    pro_1_2 = 0;
else
    pro_1_2 = Success_2 / Sum_1_2;
end
            if(Sum_1_3 == 0)
                pro_1_3 = 0;
            else
                pro_1_3 = Success_3 / Sum_1_3;
            end
rmp_1 = p_1 * pro_1_2 + (1 - p_1) * rmp_1;
rmp_2 = p_1 * pro_1_3 + (1 - p_1) * rmp_2;
                if rmp_1 <= 0
                    rmp_1 = 0;
                end
                if rmp_2 <= 0
                rmp_2 = 0; 
                end
                if rmp_2 >= 1
                rmp_2 = 1; 
                end
                if rmp_2 >= 1
                rmp_2 = 1; 
                end
    if(rmp_1 <= theta)
                Windows_1 = Windows_1 + 1;
    else
                Windows_1 = 0;
    end
    if(rmp_2 <= theta)
                Windows_2 = Windows_2 + 1;
    else
                Windows_2 = 0;
    end
                score = Cal_disp(population(1 : subpop),benchMark_num,tasks,k_optimum,gen);
population=pop_reset(population,3*subpop);
            gen = gen + 1;
if mod(gen,maxFE/1000) == 0
    Record_score(Record_index) = score;
    Record_index = Record_index + 1;
end
    end
end
Record_score(Record_index) = score;
data_MOMFEA = population(1:subpop);
end
function Mask = MaskInitialize(pop,tasks)
    Mask = false(pop,tasks.D);
    for i=1:pop
        Mask(i,TournamentSelection2(2,ceil(rand*tasks.D),ones(1,tasks.D))) = 1;
    end
end
function Dec = DecInitialize(pop,lower, upper)
    Dec = unifrnd(repmat(lower,pop,1),repmat(upper,pop,1));
end
function Dim_ranks = Tasks2_Initialize(task, k)
    Dim_ranks = zeros(1,task.D);
    cons = zeros(task.D,task.M);
    for i = 1:k
        Mask   = eye(task.D);% eye
        Dec = unifrnd(repmat(task.lower,task.D,1),repmat(task.upper,task.D,1));
        popObjs = Evaluate(Dec.*Mask, task);
        Dim_ranks = Dim_ranks + NDSort2([popObjs,cons],inf);
    end
    Dim_ranks = mapminmax(Dim_ranks,0,1);
end
function dist1 = cal_Similarity(x,y)
[m,n]=size(x);
f00 = 0;
f01 = 0;
f10 = 0;
f11 = 0;
for i=1:n
    if(x(i)==0 && y(i)==1)
        f01 = f01+1;
    elseif(x(i)==1 && y(i)==0)
        f10 = f10+1;
    elseif(x(i)==1 && y(i)==1)
        f11 = f11+1;
    else
        f00 = f00+1;
    end
end
dist1 = (f00+f11)/(f00+f01+f10+f11);
end
function [rank1,rank2] = knee_point_Group(Dim_ranks,task)
[value,index] = sort(Dim_ranks,'des');
point = [1:task.D;value];
dis = zeros(1,task.D);
for i = 1:task.D
    dis(i) = abs(det([point(:,task.D)-point(:,1),point(:,i)-point(:,1)])) / norm(point(:,task.D)-point(:,1));
end
[~,KN_point] = max(dis);
[value,index] = sort(dis,'descend');
rank1 = index(1 : KN_point);
rank2 = index(KN_point + 1 : task.D);
end
function Offspring = Boundary_treat(Offspring,tasks)
[N,D] = size(Offspring);
Lower = repmat(tasks.lower,N,1);
Upper = repmat(tasks.upper,N,1);
lower_index = Offspring < Lower;
upper_index = Offspring > Upper;
all_index = lower_index | upper_index;
New_pop = rand(N,D);
Offspring(all_index) = New_pop(all_index);
end