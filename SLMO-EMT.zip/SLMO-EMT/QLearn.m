function [data_MOMFEA,Record_score]=QLearn(pop,tasks,maxFE,reps,benchMark_num)
tic
no_of_tasks = length(tasks);
IGD =inf(1,no_of_tasks);
HV =zeros(1,no_of_tasks);
subpop = pop/no_of_tasks;
dim = length(tasks(1).upper);
for k = 2:no_of_tasks
    temp_dim = length(tasks(k).upper);
    if(temp_dim > dim)
        dim = temp_dim;
    end
end
warning off;
mu1 = [];
mu2 = [];
error = [];
error_record = [];
best_rnvec = zeros(pop,dim);

for rep = 1:reps
    %% 初始化参数
    Record_score = [];
    % mu = 0.9;     % Index of Simulated Binary Crossover (tunable)
    % mum = 20;    % Index of polynomial mutation
    [param.proC,param.disC,param.proM,param.disM] = deal(1,20,1,20); 

    
    bitwise_mu = 1/dim ;
    All_actions = [ 0.05 , 0.075 , 0.1 , 0.15 , 0.2 ];
    % action_divi = 4;
    All_states = 0:0.02:1;
    Q_tables = zeros(length(All_states),length(All_actions));% Q表格
    Q_params.alpha = 0.4;
    Q_params.gamma = 0.5;
    Q_params.epsilon = 0.1;
    State_show = zeros(1,length(All_states));
    Action_show =  zeros(1,length(All_actions));
    Gen_frequency = 5 ;

    action = 0;
    f_1 = 1;f_2 = 1;%画动态图
    a_flag = 0;% 暂时使用
    FE = 0;% 评价次数
    gen = 1;% 迭代次数
    K_iter = 3;
    %% 热启动
    % Q_tables(:,4:6) = 1;
    

    Dim_ranks = 0.5.*ones(1,dim);
    % 初始化种群
    [population,child] = initialize(pop,tasks,Dim_ranks);
    % 增加评价次数
    FE = FE + pop;
    % 排序
    population = My_environmentselect(population,subpop);
    k_optimum = getoptims(tasks);
    % 输出
    score = Cal_disp(population,benchMark_num,tasks,k_optimum,gen);
    
    
    %% 开始迭代
    gen =2;
    while FE < maxFE
        % 设计独立的父代
        parents = population;
        pop_masks = [parents.masks];
        pop_masks = reshape(pop_masks,dim,[]);
        pop_masks = pop_masks';
        %% 选择参考解
        objs = [parents.objs];
        objs = reshape(objs,tasks.M,[]);
        objs = objs';
        RN = sqrt(pop);
        theta = 1e-4;
        index = APDSelection(tasks.M,objs,RN,theta);
        %% Q-learning:得到动作并改变masks
        if(mod(gen,Gen_frequency) == 0)
            [Temp_masks,state1,action,a_index] = Operator_Q_execute(pop_masks,tasks,Q_tables,Q_params,All_actions);
        else
            Temp_masks = pop_masks;
        end
        
        %% 特征选择方法
%         Dim_ranks = 0.5.*ones(1,dim);
%         Dim_ranks = My_fea_selection(parents,tasks,Dim_ranks);

        
        %% 单点交叉搜索-masks
        tour_oder = TournamentSelection2(2,2*pop,[population.front],-[population.CD]);%锦标赛父代池,dec和masks统一用这个顺序
%         tour_oder = randperm(subpop);

        pop_masks = Temp_masks(tour_oder,:);
        pop_masks = reshape(pop_masks,dim,[]);
        pop_masks = pop_masks';
        Offspring_masks = Operator_masks(pop_masks,param,Dim_ranks);
        for i =1 : pop
            child(i).masks = Offspring_masks(i,:);
            child(i).is_child = 1;
        end

        %% SBX进化-dec
        pop_dec = [parents(tour_oder).rnvec];
        pop_dec = reshape(pop_dec,dim,[]);
        pop_dec = pop_dec';
        Offspring_dec = Operator_dec(pop_dec,tasks,param);
        for i =1 : pop
            child(i).rnvec = Offspring_dec(i,:);
        end
        %%
        % 在产生所有的子代后，复原所有父代，注意这里将子代标记置为0
        population=reset(population,pop);
        
        %% 集体评价
        for j=1:pop
            %   在评价之前进行微调，注意这里masks设置为全部一
            if strcmp(tasks.name,'Sparse_NN') == 1
                child(j).rnvec = Sparse_NN.CalDec(tasks,child(j).rnvec);
                child(j).masks = ones(1,dim);
            end
            % 测试单独dec的收敛性
%             child(j).masks = ones(1,dim);
            child(j).objs = Evaluate(child(j).rnvec .* child(j).masks,tasks);
        end
        %%
        
        % 环境选择
        intpopulation(1:pop)=population;
        intpopulation(pop+1:2*pop)=child;%混合一起
        population = My_environmentselect(intpopulation,subpop);

        % 设置环境选择后的个体
        Survive_pop = population;
        %% Q-learning：更新Q表格
        if(mod(gen,Gen_frequency) == 0)
            Q_tables = Operator_Q_update(parents,child,Survive_pop,tasks,state1,Q_tables,Q_params,a_index);
        end
        
        % 评价输出
        score = Cal_disp(Survive_pop,benchMark_num,tasks,k_optimum,gen);

        R_index = length(Record_score);
        Record_score(R_index+1) = score;
        
        FE = FE + pop;
        gen = gen + 1;
    end
end

%% 画维度值图
% figure(1)
% x = 1:1:dim/10;
% plot(x,population(1).masks(1:dim/10) .* population(1).rnvec(1:dim/10));
% % plot(x,population(1).rnvec(1:dim/10));
% axis([1 dim/10 min(tasks.lower) max(tasks.upper)])
%
% figure(2)
% x = dim/10+1:1:dim;
% plot(x,population(1).masks(dim/10+1:dim).*population(1).rnvec(dim/10+1:dim));
% % plot(x,population(1).rnvec(dim/10+1:dim));
% axis([dim/10+1 dim min(tasks.lower) max(tasks.upper)])

%% 画score图
% figure(1)
% x = 1:1:R_index+1;
% plot(x,Record_score);
%%
data_MOMFEA = population;
end