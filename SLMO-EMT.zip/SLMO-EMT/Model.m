function [data_MOMFEA,Record_score,Dim_ranks]=Model(pop,tasks,maxFE,reps,benchMark_num)
no_of_tasks = length(tasks);
IGD =inf(1,no_of_tasks);
HV =zeros(1,no_of_tasks);
subpop = pop/no_of_tasks;
dim = length(tasks(1).upper);
for k = 2:no_of_tasks
    temp_dim = length(tasks(k).upper);
    if(temp_dim > dim)
        dim = temp_dim;
    end
end
warning off;
mu1 = [];
mu2 = [];
error = [];
error_record = [];
best_rnvec = zeros(pop,dim);
%% 初始化参数
Record_score = [];% 记录IGD值
FE = 0;% 评价次数
gen = 1;% 迭代次数
[param.proC,param.disC,param.proM,param.disM] = deal(1,20,1,20); % SBX交叉变异参数
threshold = 0.99;% 设定小于此值为0
%%
for rep = 1:reps
     % 初始化种群
     Dim_ranks = 0.5.*ones(1,dim);
    [population,child] = initialize(pop,tasks,Dim_ranks);
    % 增加评价次数
    FE = FE + pop;
    % 排序
    population = My_environmentselect(population,subpop,tasks);
    k_optimum = getoptims(tasks);
%     figure(1)
%     scatter(k_optimum(:,1),k_optimum(:,2),20,'black','p','filled');
    hold on 
    % 输出
    score = Cal_disp(population,benchMark_num,tasks,k_optimum,gen);
    
    %% 开始迭代
    gen =2;
    while FE < maxFE
        tasks.FE_pro = FE/maxFE;
        tour_oder = TournamentSelection2(2,2*pop,[population.front],-[population.CD]);%锦标赛父代池,dec和masks统一用这个顺序

%         Off_dec = Gaussian_Generate(population,tasks);
%         for i =1 : pop
%             child(i).rnvec = Off_dec(i,:);
%             child(i).masks = population(i).masks;
%             child(i).is_child = 1;
%         end

%         [Off_dec,Off_masks] = Model_generate(population,tasks);
%         for i =1 : pop
%             child(i).rnvec = Off_dec(i,:);
%             child(i).masks = Off_masks(i,:);
%             child(i).is_child = 1;
%         end


        [Offspring_masks,Offspring_dec,Dim_ranks] = Operator_masks(population,tour_oder,param,Dim_ranks,tasks);
        for i =1 : pop
            child(i).masks = Offspring_masks(i,:);
            child(i).is_child = 1;
        end
        
        %% SBX进化-dec
        [Offspring_dec,Offspring_masks] = Operator_dec(population,tour_oder,tasks,param,Dim_ranks);
        for i =1 : pop
            child(i).rnvec = Offspring_dec(i,:);
            child(i).is_child = 1;
        end
        %%

        population=reset(population,pop);

        for j=1:pop

            if strcmp(tasks.name,'Sparse_NN') == 1
                child(j).rnvec = Sparse_NN.CalDec(tasks,child(j).rnvec);
                child(j).masks = ones(1,dim);
            end

%             child(j).masks = ones(1,dim);
            Mask = child(j).masks > threshold .* ones(1,tasks.D);% 小于这个概率为0
            child(j).objs = Evaluate(child(j).rnvec .* Mask,tasks);
        end
        
         % 环境选择
        intpopulation(1:pop)=population;
        intpopulation(pop+1:2*pop)=child;%混合一起
        population = My_environmentselect(intpopulation,subpop,tasks);

        % 设置环境选择后的个体
        Survive_pop = population;
        % 评价输出
        score = Cal_disp(Survive_pop,benchMark_num,tasks,k_optimum,gen);

        R_index = length(Record_score);
        Record_score(R_index+1) = score;
        
        FE = FE + pop;
        gen = gen + 1;
    end
end
%% 画维度值图
% figure(1)
% x = 1:1:dim/10;
% plot(x,population(1).masks(1:dim/10) .* population(1).rnvec(1:dim/10));
% % plot(x,population(1).rnvec(1:dim/10));
% axis([1 dim/10 min(tasks.lower) max(tasks.upper)])
%
% figure(2)
% x = dim/10+1:1:dim;
% plot(x,population(1).masks(dim/10+1:dim).*population(1).rnvec(dim/10+1:dim));
% % plot(x,population(1).rnvec(dim/10+1:dim));
% axis([dim/10+1 dim min(tasks.lower) max(tasks.upper)])

%% 画score图
% figure(1)
% x = 1:1:R_index+1;
% plot(x,Record_score);
%%
data_MOMFEA = population;
end