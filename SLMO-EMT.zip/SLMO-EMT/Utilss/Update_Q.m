function Q_tables = Update_Q(state_1,state_2,Q_tables,Q_params,reward,action)
% if state_2 <= 0.4
%     state_2 = 1;
% else
%     state_2 = round(state_2*10)-3;
% end
% state_2 = round(state_2*10);
state_2 = round(state_2*50)+1;
alpha = Q_params.alpha;
gamma = Q_params.gamma;
Q_tables(state_1,action) = (1-alpha) * Q_tables(state_1,action) + alpha * (reward + gamma * max(Q_tables(state_2,:)));

end