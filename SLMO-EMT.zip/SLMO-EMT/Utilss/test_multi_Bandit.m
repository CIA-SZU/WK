Range = a_greedy(1);

function Range = a_greedy(m)

clc,clear;
ArmN = 10; 
Epsilon = [0 0.01 0.1];
TrialN = 1000;        
LearnN = 10;        
Range = 1:TrialN;      
for epsilon = Epsilon
    reward_total_set = zeros(1,TrialN);  
    reward_set = zeros(1,TrialN);       
    OpAction_set = zeros(1,TrialN);    
    OpAction_total_set = zeros(1,TrialN);
    for m = 1:LearnN                         
       
        Value = 0.01:0.01:0.1;
        OpAction = 0;                       
        reward_total = 0;                  
        [Value_max,Value_max_a] = max(Value);
%         Q = zeros(1,ArmN);                  
        Q = 5*ones(1,ArmN);                
        N = zeros(1,ArmN);                 
        for n = 1:TrialN                    
%             [Qmax,i] = max(Q);              
            c = 0.01;
            [Qmax,i] = max(Q+c*sqrt(log(n)./N));            
            if(Qmax~=0 && rand(1)<1-epsilon) 
                action = i;                 
            else                             
                action = unidrnd(ArmN);     
            end
            reward = normrnd(Value(action),1);                         
            N(action) = N(action) + 1;                                  
%             Q(action) = Q(action) + (1/N(action)) * (reward - Q(action));
            alpha = 0.01;
            Q(action) = Q(action) + alpha * (reward - Q(action));      
            
%             Q(action) = Q(action) + alpha/(1-(1-alpha)^N(action)) * (reward - Q(action));
            reward_total = reward_total + 1/n * (reward-reward_total); 
            reward_set(n) = reward_total;                               
            if (i==Value_max_a)                                          
                OpAction = OpAction + 1; 
            end
            OpAction_set(n) = OpAction;                              
        reward_total_set = reward_total_set + 1/m * (reward_set - reward_total_set);      
        OpAction_total_set = OpAction_total_set + 1/m * (OpAction_set - OpAction_total_set);
    end
end
end