function [pop_masks,state,action,a_index] = Operator_Q_execute(pop_masks,task,Q_tables,Q_params,All_actions)
pop = size(pop_masks,1);
dim = task.D;
state = Set_State(pop_masks,task);
[state,action,a_index] = Q_learning(state,Q_tables,Q_params,All_actions);
action_rand = rand(pop,dim);
all_action = repmat(action,pop,dim);
do_change = action_rand < all_action;
pop_masks(do_change) = 0;
end
function state = Set_State(pop_masks,task)
pop = size(pop_masks,1);
dim = task.D;
zero_num = 0;
for m=1:pop
    zero_num = zero_num + length(find(pop_masks(m,:) == 0));
end
state= (zero_num / pop) / dim;
end