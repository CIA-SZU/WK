function [state,action,a_index] = Q_learning(state,Q_tables,Q_params,All_actions)
% state = 0.95;

% if state <= 0.4
%     state = 1;
% else
%     state = round(state*10)-3;
% end
% state = round(state*10);
state = round(state*50)+1;
possible_actions = 1:1:length(All_actions);
possible_Q=Q_tables(state,possible_actions);
if rand(1)<Q_params.epsilon
    choose=unidrnd(length(possible_actions));
    action=possible_actions(choose);
else
    [value,index]=max(possible_Q);
    index_all = find(possible_Q==value);
    if(length(index_all) > 1)
        inorder = randperm(length(index_all));
        index = index_all(inorder(1));
    end
    action=possible_actions(index);
end
a_index = action;
action = All_actions(action);
end