function Q_tables = Operator_Q_update(parents,childs,Survive_pop,task,state1,Q_tables,Q_params,a_index)
dim = task.D;
pop = length(parents);
[reward,vector_sets] = Get_Reward(parents,childs,Survive_pop,task);

zero_num = 0;
for m=1:pop
    zero_num = zero_num + length(find(Survive_pop(m).masks == 0));
end
state_2= (zero_num / pop) / dim;
Q_tables = Update_Q(state1,state_2,Q_tables,Q_params,reward,a_index);
end

function [reward,vector_sets] = Get_Reward(parents,childs,Survive_pop,task)
pop = length(parents);
refer_vector = UniformPoint(pop/2,task.M);
vector_sets = cell(1,length(refer_vector));
no_of_objs = task.M;

success_child = [Survive_pop.is_child];
success_child = sum(success_child);
reward_1 = exp(success_child/pop * 5)-1;
all_costs = [parents.objs];
all_costs = reshape(all_costs,no_of_objs,[]);
all_costs = all_costs';
idea_z = min(all_costs,[],1);% idea point
for p = 1:pop
    [min_value,min_index] = min(pdist2(all_costs(p,:)-idea_z, refer_vector ,'cosine'));
    curr_set = vector_sets{min_index};
    curr_k = length(curr_set);
    curr_set(curr_k+1) = p;
    vector_sets{min_index} = curr_set;
end
childs_costs = [childs.objs];
childs_costs = reshape(childs_costs,no_of_objs,[]);
childs_costs = childs_costs';
idea_z_child = min(childs_costs,[],1);% idea point
for p = 1:pop
    [min_value,min_index] = min(pdist2(childs_costs(p,:)-idea_z, refer_vector ,'cosine'));
    curr_pa_set = vector_sets{min_index};
    if isempty(curr_pa_set)
        rewards_2 = sum(childs_costs(p,:)-idea_z);
    else 
        pa_costs = [parents(curr_pa_set).objs];
        pa_costs = reshape(pa_costs,no_of_objs,[]);
        pa_costs = pa_costs';
        non_index = Nondominated_sort(pa_costs);
        if(length(non_index) > 1) 
            non_value = mean(pa_costs(non_index,:));
        else
            non_value = pa_costs(non_index,:);
        end
        
        rewards_2 = sum(non_value - childs_costs(p,:)) ;
    end
end

reward = reward_1;
end