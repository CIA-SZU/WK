function [index,dominated_sets] = Nondominated_sort(costs)
    N = size(costs,1);
    if N == 1 
        index = 1;
    else
    M = size(costs,2);
    dominated_sets = zeros(1,N); 
    for i = 1:N
        for j = 1:N
           if(i ~= j)
               values = costs(i,:) - costs(j,:); 
               number = length(find(values >= 0));
               if(number == M)
                   dominated_sets(i) = dominated_sets(i) + 1;
               end
           end
        end
    end
    
    index = find(dominated_sets == 0);
    
    end
end