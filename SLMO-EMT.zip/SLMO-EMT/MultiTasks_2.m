function [data_MOMFEA,Record_score,Dim_ranks]=MultiTasks_2(subpop,tasks,maxFE,reps,benchMark_num)
warning off;

no_of_tasks = 3;
IGD =inf(1,no_of_tasks);
HV =zeros(1,no_of_tasks);
pop = subpop * no_of_tasks;
dim = length(tasks(1).upper);

Record_score = [];
FE = 0;
gen = 1;

[param.proC,param.disC,param.proM,param.disM] = deal(1,20,1,20); 
Record_sparse = [];
Record_allO_Z = [];
entropy = [];
Nondominated_Sets = [];
PV = 0.5 * ones(1,dim);

k_optimum = getoptims(tasks);
rmp_1 = 0.5;
rmp_2 = 0.5;
Windows_1 = 0;
Windows_2 = 0;
Dim_ranks_2 = 0.5 * ones(1,tasks.D);
%%
for rep = 1:reps
     Dim_ranks = 0.5.*ones(1,dim);
     [population,~] = initialize(subpop,tasks,Dim_ranks);
     for i= 1:subpop
         population(i).skill_factor = 1;
     end
     FE = FE + subpop;

     population(1 : subpop ) = My_environmentselect(population(1 : subpop),subpop,tasks);
     score = Cal_disp(population(1 : subpop ),benchMark_num,tasks,k_optimum,gen);
 
     Pareto_pop = population([population.front] == 1);
     Masks_1 = [Pareto_pop.masks]; Masks_1 = reshape(Masks_1,tasks.D,[]); Masks_1 = Masks_1';
     Dec_1 = [Pareto_pop.rnvec]; Dec_1 = reshape(Dec_1,tasks.D,[]); Dec_1 = Dec_1';
     M_Masks_1 = mean(Masks_1);
     
     Dec_Bind = Pareto_pop(randperm(length(Pareto_pop),1)).rnvec;
     M_M_ranks_1 = abs(M_Masks_1 - 0.5);
     [values, index] = sort(M_M_ranks_1);
     index_range_1 = find(M_M_ranks_1 <= 0.1);
     index_range_2 = find(M_M_ranks_1 <= 0.2);
     index_range_3 = find(M_M_ranks_1 <= 0.3);
     if length(index_range_1) >= tasks.D / 3
         Subtask_2_range = index_range_1;
     else
         Subtask_2_range = index_range_2;
     end
    
     St_2_Sparse_D = M_Masks_1(Subtask_2_range);

     Dim_ranks_1 = Tasks2_Initialize(tasks, 5);


     for i= 1+subpop : 2*subpop
         R = rand(1,tasks.D);
         population(i).masks = R < M_Masks_1;
         population(i).rnvec = Dec_Bind;
         population(i).skill_factor = 2;
         population(i).objs = Evaluate(Dec_Bind .* population(i).masks ,tasks);
     end
     FE = FE + subpop;
     

     bound_sub_t2 = 0.2;
    Masks_Bind = Pareto_pop(randperm(length(Pareto_pop),1)).masks;
    [~,index] = sort(M_Masks_1);
    index = index(1: 0.1 * tasks.D);
    index_2 = randperm(0.1 * tasks.D, 0.01 * tasks.D);
    Subtask_3_range = index(index_2);
    Masks_Bind(Subtask_3_range) = 1;


    Dec = DecInitialize(subpop, min(Dec_1), max(Dec_1));
     j = 1;
     for i= 1+2 * subpop : 3*subpop
         population(i).rnvec = Dec(j,:);
         population(i).masks = Masks_Bind;
         j = j + 1;
         population(i).skill_factor = 3;
         population(i).objs = Evaluate(Masks_Bind .* population(i).rnvec ,tasks);
     end
     FE = FE + subpop;
    for i = 2:no_of_tasks
        population((i-1)*subpop+1 : i*subpop ) = My_environmentselect(population((i-1)*subpop+1 : i*subpop ),subpop,tasks);
        score = Cal_disp(population((i-1)*subpop+1 : i*subpop ),benchMark_num,tasks,k_optimum,gen);
    end
    
    gen =2;
    while FE < maxFE
        sub_population_1 = population(1:subpop);
        if(rmp_1 < 0.3)
            Windows_1 = Windows_1 + 1;
        else
            Windows_1 = 0;
        end
        
        if(Windows_1 == 5)
            [sub_population_2,Subtask_2_range,St_2_Sparse_D] = Task_1_generate(sub_population_1, tasks);
            population(1+subpop :2*subpop) = sub_population_2;
            Windows_1 = 0;
            rmp_1 = 0.5;

            FE = FE + subpop;
        end
        
        if(rmp_2 < 0.2)
            Windows_2 = Windows_2 + 1;
        else
            Windows_2 = 0;
        end
        
        if(Windows_2 == 5)
            [sub_population_3,Subtask_3_range] = Task_2_generate(sub_population_1, tasks);
            population(1+2*subpop :3*subpop) = sub_population_3;
            Windows_2 = 0;
            rmp_2 = 0.5;

            FE = FE + subpop;
        end
        
        if(FE < maxFE/100)
           no_of_tasks = 2;
        else 
%             disp(['子任务2加入']);
            [sub_population_3,Subtask_3_range] = Task_2_generate(sub_population_1, tasks);
            population(1+2*subpop :3*subpop) = sub_population_3;
            no_of_tasks = 3;
        end
        
        for i = 1:no_of_tasks

            sub_population = population((i-1)*subpop+1 : i*subpop);
            
            if(i == 1)
                sub_population_2 = population(subpop+1 : 2*subpop);
                sub_population_3 = population(2*subpop+1 : 3*subpop);
                if(mod(gen,2) == 0)
                    [sub_population, rmp_1] = Search_1_2(rmp_1, sub_population, tasks, sub_population_2, Subtask_2_range, St_2_Sparse_D);
                elseif(mod(gen,2) == 1 && no_of_tasks == 3)
                    [sub_population, rmp_2]  = Search_1_3(sub_population, tasks, sub_population_3,Subtask_3_range, rmp_2);
                end
                FE = FE + subpop;
            end
            
            if(i == 2)
                sub_population = MasksSearch_2_All(sub_population, tasks, Subtask_2_range);
                FE = FE + length(sub_population);
            end
            
            if(i == 3)
                sub_population = DecSearch_3_All(sub_population, tasks);
                FE = FE + subpop;
            end
            

            score = Cal_disp(sub_population,benchMark_num,tasks,k_optimum,gen);
            index = IndexShow(sub_population,tasks);


            population((i-1)*subpop+1 : i*subpop) = sub_population;
            %
        end

        gen = gen + 1;
    end
end
data_MOMFEA = population;
end


function Mask = MaskInitialize(pop,tasks)
    Mask = false(pop,tasks.D);
    for i=1:pop
        Mask(i,TournamentSelection2(2,ceil(rand*tasks.D),ones(1,tasks.D))) = 1;
    end
end

function Dec = DecInitialize(pop,lower, upper)
    Dec = unifrnd(repmat(lower,pop,1),repmat(upper,pop,1));
end





function Dim_ranks = Tasks2_Initialize(task, k)
    Dim_ranks = zeros(1,task.D);
    cons = zeros(task.D,task.M);
    for i = 1:k
        Mask   = eye(task.D);% eye
        Dec = unifrnd(repmat(task.lower,task.D,1),repmat(task.upper,task.D,1));
        popObjs = Evaluate(Dec.*Mask, task);
        Dim_ranks = Dim_ranks + NDSort2([popObjs,cons],inf);

    Dim_ranks = mapminmax(Dim_ranks,0,1);

end

% function 


function dist1 = cal_Similarity(x,y)
[m,n]=size(x);
f00 = 0;
f01 = 0;
f10 = 0;
f11 = 0;
for i=1:n
    if(x(i)==0 && y(i)==1)
        f01 = f01+1;
    elseif(x(i)==1 && y(i)==0)
        f10 = f10+1;
    elseif(x(i)==1 && y(i)==1)
        f11 = f11+1;
    else
        f00 = f00+1;
    end
end
dist1 = (f00+f11)/(f00+f01+f10+f11);

% dist1 = floor(dist1*10) + 1;
end

function [rank1,rank2] = knee_point_Group(Dim_ranks,task)

[value,index] = sort(Dim_ranks,'des');
point = [1:task.D;value];
dis = zeros(1,task.D);
for i = 1:task.D
    dis(i) = abs(det([point(:,task.D)-point(:,1),point(:,i)-point(:,1)])) / norm(point(:,task.D)-point(:,1));
end
[~,KN_point] = max(dis);
[value,index] = sort(dis,'descend');
rank1 = index(1 : KN_point);
rank2 = index(KN_point + 1 : task.D);
end

function Offspring = Boundary_treat(Offspring,tasks)
[N,D] = size(Offspring);

Lower = repmat(tasks.lower,N,1);
Upper = repmat(tasks.upper,N,1);
lower_index = Offspring < Lower;
upper_index = Offspring > Upper;
all_index = lower_index | upper_index;
New_pop = rand(N,D);
% New_pop = ones(N,D);
Offspring(all_index) = New_pop(all_index);


end
