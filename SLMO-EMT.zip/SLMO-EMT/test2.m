% 设置问题参数
n = 100; % 变量维数
m = 3; % 目标函数数
lb = -10 * ones(n,1); % 变量下界
ub = 10 * ones(n,1); % 变量上界

% 定义适应度函数
fitnessfcn = @(x) [sum(abs(x)), sum(x.^2), sum(sin(x).^2)];

% 设置差分进化算法参数
opts = optimoptions('fmincon', 'Algorithm', 'interior-point', ...
    'MaxIterations', 500, 'Display', 'iter');

% 运行差分进化算法求解
[x, fval, exitflag, output] = ...
    multiobjectiveDE(fitnessfcn, n, m, lb, ub, [], opts);

% 输出结果
disp('最优解：');
disp(x);
disp('最优目标函数值：');
disp(fval);
disp('算法退出标志：');
disp(exitflag);
disp('算法输出信息：');
disp(output);
