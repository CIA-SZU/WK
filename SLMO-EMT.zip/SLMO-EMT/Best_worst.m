function [Record,Number1,entropy] = Best_worst(population,tasks,Record,Number1,entropy)

Parent_masks = [population.masks];Parent_masks = reshape(Parent_masks,tasks.D,[]);Parent_masks = Parent_masks';
costs = [population.objs];  costs = reshape(costs,tasks.M,[]);  costs = costs';
Parent_dec = [population.rnvec];Parent_dec = reshape(Parent_dec,tasks.D,[]);Parent_dec = Parent_dec';
Zero_pop = sum(Parent_masks,2);
[~,index] = sort(Zero_pop);
Record(end+1) = Zero_pop(index(end))-Zero_pop(index(1));
Temp_costs = [costs(index(end),:);costs(index(1),:)];
Masks1 = mean(Parent_masks);
Number1(end+1) = length(find(Masks1 == 1));
Number1(end) = length(find(Masks1 == 0)) + Number1(end);
Masks2 = mean(Parent_masks);
Masks21 = 1-Masks2;
Masks22 = [Masks2;Masks21];
for i=1:tasks.D
    entropy(i) = sum(-Masks22(:,i).*log2(Masks22(:,i)));
    if(isnan(entropy(i)))
        entropy(i) = 0;
    end
end
A=length(find(Masks1(1:1001) == 0));
B=length(find(Masks1(1002:end) == 1));
best_pop = population([population.front]==1);
dec = [best_pop.rnvec];     dec = reshape(dec,tasks.D,[]);      dec = dec';
temp_dec = dec(:,2:tasks.D/10+1);
flag1 = 0;
for i=1:length(temp_dec(:))
    if(temp_dec(i)>1&&temp_dec(i)<1.1)
        flag1 = flag1 + 1;
    end
end
flag1 = flag1/length(temp_dec(:));
temp_dec = Parent_dec(:,2:tasks.D/10+1);
flag2 = 0;
for i=1:length(temp_dec(:))
    if(temp_dec(i)>1&&temp_dec(i)<1.1)
        flag2 = flag2 + 1;
    end
end
flag2 = flag2/length(temp_dec(:));
end